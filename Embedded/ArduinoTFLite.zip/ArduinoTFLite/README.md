# ArduinoTFLite
## A TensorFlow Lite Micro Library in Arduino Style

This library simplifies the use of **TensorFlow Lite Micro** on Arduino boards, offering APIs in the typical _Arduino style_. It avoids the use of _pointers_ or other C++ syntactic constructs that are discouraged within an Arduino sketch.
It was inspired by ArduTFLite and depends on Chirale_TensorFlowLite, but is more geared towards those who wish to learn about the process of deploying **TensorFlow** models on constrained edge devices.

**ArduinoTFLite** serves as a wrapper for the _Chirale_TensorFlowLite library_, which is a port of the official TensorFlow Lite Micro library for Arduino boards with ARM and ESP32 architecture.

**ArduinoTFLite** is designed to enable experimentation with **Tiny Machine Learning** on Arduino boards with greater resources, such as **Arduino Nano 33 BLE**, **Arduino Nano ESP32**, **Arduino Nicla**, **Arduino Portenta** and **Arduino Giga R1 WiFi**. Usage is simple and straightforward and You don't need an extensive TensorFlow expertise to code your sketches and the library provides an extensive API that allows you explore the internal meta data of the model.

## Installation

The library can be installed from the Arduino IDE Library Manager or can be installed as .zip file downloaded from this GitHub repository.
The library depends on the Chirale_TensorFlowLite library.

## Usage examples

The examples included with the library show how to use the library. The examples include their pre-trained models.

## General TinyML development process:

1. **Create an Arduino Sketch to collect data suitable for training**: First, create an Arduino sketch to collect data to be used as the training dataset.
2. **Define a DNN model**: Once the training dataset is acquired, create a neural network model using an external TensorFlow development environment, such as Google Colaboratory.
3. **Train the Model**: Import training data on the TensorFlow development environment and train the model on the training dataset.
4. **Convert and Save the Model**: Convert the trained model to TensorFlow Lite format and save it as a `model.h` file. This file should contain the definition of a static byte array corresponding to the binary format (flat buffer) of the TensorFlow Lite model.
5. **Prepare a new Arduino Sketch for Inference**
6. **Include Necessary Headers**: Include the `ArduTFLite.h` header file and the `model.h` file.
7. **Define Tensor Arena**: Define a globally sized byte array for the area called tensorArena.
8. **Initialize the Model**: Initialize the model using the `ModelInit()` function.
9. **Set Input Data**: Insert the input data into the model's input tensor using the `ModelSetInput()` function.
10. **Run Inference**: Invoke the inference operation using the `ModelRunInference()` function.
11. **Read Output Data**: Read the output data using the `ModelGetOutput()` function.

## Reference

# ArduinoTFLite Library Documentation

## Reference

### **Function**

**bool ModelInit(const unsigned char* model, byte* tensorArena, int tensorArenaSize);**

*Initializes TensorFlow Lite Micro environment, instantiates an `AllOpsResolver`, and allocates input and output tensors.*

**Parameters:**

- `model`: A pointer to the model data.
- `tensorArena`: A memory buffer to be used for tensor allocations.
- `tensorArenaSize`: The size of the tensor arena.

**Returns:**  
`true` = success, `false` = failure.

---

### **Function**

**bool ModelSetInput(float inputValue, int index, bool showQuantizedValue = false);**

*Writes `inputValue` in the position `index` of the input tensor, automatically handling quantization if the tensor is of type `int8`.*

**Parameters:**

- `inputValue`: The input value to be written to the tensor.
- `index`: The position in the input tensor where the value is written.
- `showQuantizedValue`: (Optional) If `true`, prints the quantized value for debugging purposes.

**Returns:**  
`true` = success, `false` = failure.

---

### **Function**

**bool ModelRunInference();**

*Invokes the TensorFlow Lite Micro Interpreter and executes the inference algorithm.*

**Returns:**  
`true` = success, `false` = failure.

---

### **Function**

**float ModelGetOutput(int index);**

*Returns the output value from the position `index` of the output tensor, automatically handling dequantization if the tensor is of type `int8`.*

**Parameters:**

- `index`: The position in the output tensor from which to retrieve the result.

**Returns:**  
The output value from the tensor, or `-1` if there was an error.

---

### **Function**

**void ModelPrintInputTensorDimensions();**

*Prints the dimensions of the input tensor.*

**Description:**  
Prints the size and dimensionality of the input tensor to the Serial Monitor, allowing the user to check how the input data should be structured.

---

### **Function**

**void ModelPrintOutputTensorDimensions();**

*Prints the dimensions of the output tensor.*

**Description:**  
Prints the size and dimensionality of the output tensor to the Serial Monitor, providing insight into the model’s output shape.

---

### **Function**

**void ModelPrintTensorQuantizationParams();**

*Prints the quantization parameters for both the input and output tensors.*

**Description:**  
Prints the scale and zero-point values for the input and output tensors, which are crucial for understanding how floating-point values are converted to and from quantized integer values.

---

### **Function**

**void ModelPrintMetadata();**

*Prints metadata information about the model, including description and version.*

**Description:**  
If the model contains a description, it will be printed along with the model version. If no description is available, it will indicate so.

---

### **Function**

**void ModelPrintTensorInfo();**

*Prints detailed information about the input and output tensors, including their types and dimensions.*

**Description:**  
Prints the data type (e.g., `int8` or `float32`) and the size of each dimension for both the input and output tensors.

---

### **Helper Functions**

#### **Quantization Functions**

**int8_t QuantizeInput(float x, float scale, float zeroPoint);**

*Quantizes a floating-point value to an `int8_t` value based on the provided scale and zero point.*

**Parameters:**

- `x`: The floating-point input value.
- `scale`: The quantization scale.
- `zeroPoint`: The quantization zero point.

**Returns:**  
The quantized `int8_t` value.

---

**float DequantizeOutput(int8_t quantizedValue, float scale, float zeroPoint);**

*Dequantizes an `int8_t` output value back to a floating-point value based on the provided scale and zero point.*

**Parameters:**

- `quantizedValue`: The quantized `int8_t` output value.
- `scale`: The quantization scale.
- `zeroPoint`: The quantization zero point.

**Returns:**  
The dequantized floating-point value.
